import { VariantProps } from 'class-variance-authority';
import { ComponentProps, FC } from 'react';
declare const badgeVariants: (props?: ({
    type?: "icon" | "dot" | "badge" | null | undefined;
    style?: "filled" | "filled-tonal" | "outlined" | null | undefined;
    size?: "default" | "dense" | null | undefined;
    color?: "primary" | "secondary" | "action" | "error" | "warning" | "success" | "grey" | "custom" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
type IBadgeProps = VariantProps<typeof badgeVariants> & ComponentProps<'div'>;
export declare const Badge: FC<IBadgeProps>;
export {};
