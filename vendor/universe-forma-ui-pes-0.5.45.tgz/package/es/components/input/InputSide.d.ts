import { ReactNode } from 'react';
interface IInputSideProps {
    icon?: ReactNode;
    text?: string;
    size: 'dense' | 'lg' | null | undefined;
    disabled?: boolean;
    position: 'left' | 'right';
    isError?: boolean;
    isFocused?: boolean;
    isHovered?: boolean;
}
export declare const InputSide: import('react').NamedExoticComponent<IInputSideProps>;
export {};
