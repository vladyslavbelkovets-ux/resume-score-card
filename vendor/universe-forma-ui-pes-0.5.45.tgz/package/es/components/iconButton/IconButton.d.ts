import { VariantProps } from 'class-variance-authority';
import { ComponentProps } from 'react';
declare const iconButtonVariants: (props?: ({
    variant?: "text" | "filled" | "filled-tonal" | "outlined" | null | undefined;
    color?: "primary" | "action" | "error" | null | undefined;
    size?: "xs" | "sm" | "md" | "lg" | "ms" | null | undefined;
    iconSize?: "lg" | "default" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
type IconButtonProps = Omit<ComponentProps<'button'>, 'color'>;
interface IIconButtonProps extends IconButtonProps, VariantProps<typeof iconButtonVariants> {
    asChild?: boolean;
}
export declare const IconButton: import('react').NamedExoticComponent<Omit<IIconButtonProps, "ref"> & import('react').RefAttributes<HTMLButtonElement>>;
export {};
