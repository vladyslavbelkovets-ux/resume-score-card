import { VariantProps } from 'class-variance-authority';
import { FC, ReactNode } from 'react';
declare const toastVariants: (props?: ({
    variant?: "filled" | "filled-tonal" | "outlined" | null | undefined;
    color?: "primary" | "action" | "error" | "warning" | "success" | "info" | null | undefined;
    size?: "sm" | "md" | "default" | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
interface ToastProps extends VariantProps<typeof toastVariants> {
    title: ReactNode;
    description?: ReactNode;
    actionText?: ReactNode;
    onActionClick?: () => void;
    customAction?: ReactNode;
    onClose: () => void;
    canClose?: boolean;
    className?: string;
    customIcon?: ReactNode;
}
export declare const Toast: FC<ToastProps>;
export {};
