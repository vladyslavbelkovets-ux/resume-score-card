import { FC } from 'react';
interface IToasterProps {
    containerId?: string;
}
export declare const Toaster: FC<IToasterProps>;
export {};
