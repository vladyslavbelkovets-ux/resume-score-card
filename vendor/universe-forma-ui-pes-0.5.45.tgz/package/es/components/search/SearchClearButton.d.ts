import { ComponentProps, PointerEvent } from 'react';
import { Input } from '../input';
interface ISearchClearButtonProps {
    onClear?: () => void;
    clearText?: string;
    searchSize: ComponentProps<typeof Input>['size'];
    onPointerDown?: (event: PointerEvent) => void;
}
export declare const SearchClearButton: ({ onClear, clearText, searchSize, onPointerDown }: ISearchClearButtonProps) => import("react/jsx-runtime").JSX.Element;
export {};
