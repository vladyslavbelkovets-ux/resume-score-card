import { ComponentProps } from 'react';
import { Input } from '../input';
interface ISearchSubmitButtonProps {
    hasValue: boolean;
    onSubmit?: () => void;
    findText?: string;
    searchSize: ComponentProps<typeof Input>['size'];
}
export declare const SearchSubmitButton: ({ hasValue, onSubmit, findText, searchSize }: ISearchSubmitButtonProps) => import("react/jsx-runtime").JSX.Element;
export {};
