import { VariantProps } from 'class-variance-authority';
import { ComponentProps, JSX, ReactNode } from 'react';
declare const buttonVariants: (props?: ({
    size?: "sm" | "md" | "lg" | "ms" | null | undefined;
    variant?: "text" | "filled" | "filled-tonal" | "outlined" | "upsale" | null | undefined;
    color?: "primary" | "secondary" | "action" | "error" | null | undefined;
    loading?: boolean | null | undefined;
} & import('class-variance-authority/types').ClassProp) | undefined) => string;
type ButtonProps = Omit<ComponentProps<'button'>, 'size' | 'variant' | 'color'>;
interface IButtonProps extends ButtonProps, VariantProps<typeof buttonVariants> {
    asChild?: boolean;
    leftIcon?: ReactNode;
    rightIcon?: ReactNode;
    element?: keyof JSX.IntrinsicElements;
}
export declare const Button: import('react').NamedExoticComponent<Omit<IButtonProps, "ref"> & import('react').RefAttributes<HTMLButtonElement>>;
export {};
