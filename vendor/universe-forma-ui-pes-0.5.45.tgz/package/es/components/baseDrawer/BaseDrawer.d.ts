import { Drawer } from 'vaul';
import { ComponentProps, ReactNode } from 'react';
interface IBaseDrawerProps extends ComponentProps<typeof Drawer.Content> {
    open?: boolean;
    onOpenChange?: (open: boolean) => void;
    direction?: 'top' | 'bottom' | 'left' | 'right';
    trigger?: ReactNode;
    overlayClassName?: string;
    modal?: boolean;
    fixed?: boolean;
    canCloseWithDrag?: boolean;
    canClose?: boolean;
}
export declare const BaseDrawer: import('react').NamedExoticComponent<Omit<IBaseDrawerProps, "ref"> & import('react').RefAttributes<HTMLDivElement>>;
export {};
