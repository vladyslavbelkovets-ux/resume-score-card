import { ComponentProps, FC } from 'react';
import { Content as RadixTabsContent } from '@radix-ui/react-tabs';
export declare const TabsContent: FC<ComponentProps<typeof RadixTabsContent>>;
