import { ComponentProps, FC } from 'react';
import { Trigger as RadixTabsTrigger } from '@radix-ui/react-tabs';
import { ITabsStylesProps } from './state/tabsContext';
type ITabsTriggerProps = Omit<ComponentProps<typeof RadixTabsTrigger>, keyof ITabsStylesProps> & Partial<ITabsStylesProps>;
export declare const TabsTrigger: FC<ITabsTriggerProps>;
export {};
