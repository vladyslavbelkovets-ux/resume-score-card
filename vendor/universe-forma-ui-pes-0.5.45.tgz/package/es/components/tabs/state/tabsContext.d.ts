export interface ITabsStylesProps {
    transparent: boolean;
    color: 'grey' | 'primary';
    size: 'md' | 'sm';
    scrollable: boolean;
}
export interface ITabsContext extends ITabsStylesProps {
    value: string;
}
export declare const TabsContext: import('react').Context<ITabsContext>;
export declare const useTabsContext: () => ITabsContext;
