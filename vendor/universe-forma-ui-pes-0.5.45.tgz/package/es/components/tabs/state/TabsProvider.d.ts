import { ITabsContext } from './tabsContext';
import { FC, PropsWithChildren } from 'react';
export declare const TabsProvider: FC<ITabsContext & PropsWithChildren>;
