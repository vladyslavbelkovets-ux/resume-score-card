import { ComponentProps, FC } from 'react';
import { Root as RadixTabsRoot } from '@radix-ui/react-tabs';
import { ITabsContext } from './state/tabsContext';
type ITabsRootProps = Omit<ComponentProps<typeof RadixTabsRoot>, keyof ITabsContext> & ITabsContext;
export declare const TabsRoot: FC<ITabsRootProps>;
export {};
