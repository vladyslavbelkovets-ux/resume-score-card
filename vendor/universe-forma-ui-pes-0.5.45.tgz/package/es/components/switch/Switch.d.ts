import { ComponentProps, FC, ReactNode } from 'react';
import * as SwitchPrimitive from '@radix-ui/react-switch';
interface ISwitchProps extends Omit<ComponentProps<typeof SwitchPrimitive.Root>, 'children'> {
    containerClassName?: string;
    color: 'primary' | 'action';
    size: 'md' | 'sm';
    icon?: ReactNode | 'check' | 'minus';
    labelLeft?: ReactNode;
    labelRight?: ReactNode;
}
export declare const Switch: FC<ISwitchProps>;
export {};
