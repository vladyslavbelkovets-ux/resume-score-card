import { OperatingSystem } from './types';
export declare function matchMobileUA(ua: string): boolean;
export declare function matchTabletUA(ua: string): boolean;
export declare function detectOS(ua: string): OperatingSystem;
