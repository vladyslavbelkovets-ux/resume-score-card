import { OrientationInfo } from './types';
/** Reads current orientation. Prefers Screen Orientation API, falls back to window dimensions. */
export declare function getOrientation(): OrientationInfo;
/** Reactive orientation hook. Uses Screen Orientation API with resize fallback. */
export declare function useOrientation(): OrientationInfo;
