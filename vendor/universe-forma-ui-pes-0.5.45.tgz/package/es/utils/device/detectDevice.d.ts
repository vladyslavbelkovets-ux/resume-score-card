import { DetectOptions, DeviceInfo, DeviceType, OperatingSystem } from './types';
export declare function isMobile(ua?: string): boolean;
export declare function isTablet(ua?: string): boolean;
export declare function isDesktop(ua?: string): boolean;
export declare function isTouchDevice(): boolean;
export declare function isIOS(ua?: string): boolean;
export declare function isAndroid(ua?: string): boolean;
export declare function getDeviceType(ua?: string): DeviceType;
export declare function getOS(ua?: string): OperatingSystem;
/** Full device info snapshot. Accepts an optional strategy override. */
export declare function detectDevice(options?: DetectOptions): DeviceInfo;
