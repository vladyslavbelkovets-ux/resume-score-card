export type DeviceType = 'mobile' | 'tablet' | 'desktop';
export type OperatingSystem = 'ios' | 'android' | 'windows' | 'macos' | 'linux' | 'unknown';
export type Orientation = 'portrait' | 'landscape';
export type DeviceStrategy = (ua: string) => DeviceType;
export interface DetectOptions {
    ua?: string;
    strategy?: DeviceStrategy;
}
export interface DeviceInfo {
    type: DeviceType;
    os: OperatingSystem;
    isMobile: boolean;
    isTablet: boolean;
    isDesktop: boolean;
    isTouchDevice: boolean;
    isIOS: boolean;
    isAndroid: boolean;
}
export interface OrientationInfo {
    orientation: Orientation;
    angle: number;
    isPortrait: boolean;
    isLandscape: boolean;
}
