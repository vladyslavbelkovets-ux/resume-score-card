export { isMobile, isTablet, isDesktop, isTouchDevice, isIOS, isAndroid, getDeviceType, getOS, detectDevice } from './detectDevice';
export { byUserAgent, byMediaQuery, hybrid, fallback, consensus, majority, chain } from './strategies';
export { useDeviceDetect } from './useDeviceDetect';
export { getOrientation, useOrientation } from './useOrientation';
export type { DeviceInfo, DeviceType, DeviceStrategy, DetectOptions, OperatingSystem, Orientation, OrientationInfo } from './types';
