import { DeviceStrategy } from './types';
/** iPads on iOS 13+ report platform as 'MacIntel' but expose touch points. */
export declare function checkIPadOS(): boolean;
/** Pure UA string matching. No browser APIs — works on client and server. */
export declare const byUserAgent: DeviceStrategy;
/** CSS media queries + hardware capabilities. Client-only, returns 'desktop' on server. */
export declare const byMediaQuery: DeviceStrategy;
/** UA first, then iPadOS patch, then media query cross-check. Default strategy. */
export declare const hybrid: DeviceStrategy;
/** First non-desktop result wins. Returns 'desktop' only if all strategies agree. */
export declare function fallback(...strategies: DeviceStrategy[]): DeviceStrategy;
/** Returns the result only when all strategies agree. 'desktop' on disagreement. */
export declare function consensus(...strategies: DeviceStrategy[]): DeviceStrategy;
/** Majority vote. Returns 'desktop' on ties. */
export declare function majority(...strategies: DeviceStrategy[]): DeviceStrategy;
interface ChainBuilder {
    use(strategy: DeviceStrategy): ChainBuilder;
    fallback(): DeviceStrategy;
    consensus(): DeviceStrategy;
    majority(): DeviceStrategy;
}
/** Fluent builder: chain strategies with .use(), resolve with .fallback() / .consensus() / .majority(). */
export declare function chain(...initial: DeviceStrategy[]): ChainBuilder;
export {};
