import { DetectOptions, DeviceInfo } from './types';
/** Reactive wrapper around detectDevice. Re-evaluates on pointer/hover media query changes. */
export declare function useDeviceDetect(options?: DetectOptions): DeviceInfo;
