import { RefObject } from 'react';
export declare const isObjectRef: (ref: unknown) => ref is RefObject<HTMLInputElement>;
