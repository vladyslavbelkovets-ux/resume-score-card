type DeviceSizeKey = keyof typeof DEVICE_SIZES_MAP;
type Direction = 'min' | 'max';
export type BreakpointKey = `${Direction}-${DeviceSizeKey}`;
export declare const DEVICE_SIZES_MAP: {
    /** 360px */
    xs: string;
    /** 600px */
    sm: string;
    /** 1024px */
    md: string;
    /** 1440px */
    lg: string;
};
/** Hook for adapting UI to different screen sizes
 * use it only in cases when it is impossible to use tailwind media queries

 * @example useMediaQuery('min-xs') => \@media (min-width: 360px) | \@media (max-width: 22.5rem)
 * @example useMediaQuery('max-sm') => \@media (max-width: 599px) | \@media (max-width: 37.5rem)
 * @example useMediaQuery('min-md') => \@media (min-width: 600px) | \@media (min-width: 64rem)
 * @example useMediaQuery('max-md') => \@media (max-width: 1024px) | \@media (max-width: 64rem)
 * @example useMediaQuery('max-lg') => \@media (max-width: 1440px) | \@media (max-width: 90rem)
 */
export declare function useMediaQuery(key: BreakpointKey): boolean;
export {};
