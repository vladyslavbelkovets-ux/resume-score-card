import { RefObject } from 'react';
export declare const useHasScroll: (ref: RefObject<HTMLElement>) => boolean;
